import React from 'react'
import '../App.css'
function Sidebar_option(props) {
  return (
    <button className="bg-gray-300 hover:bg-gray-800 text-black hover:text-gray-50 transition-all ease-in  text-white w-full text-left px-4 py-2 rounded-lg">{props.option}</button>
  )
}

export default Sidebar_option   