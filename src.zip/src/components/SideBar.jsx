import React from 'react'
import Sidebar_option from './Sidebar_option'

function SideBar(props) {

console.log(props.options['WMS'])
  return (
    <div className='block'>
          <div className="font-bold p-2 mb-4 text-left text-xl  underline underline-offset-1">Warehouse Management</div>
          <div className="space-y-4 flex flex-col">
          {props.options['WMS'].map((x)=><Sidebar_option  option={x} />)}
          </div>

        </div>
  )
}

export default SideBar