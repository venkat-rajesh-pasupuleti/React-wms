import './App.css';
import SideBar from './components/SideBar';
import Sidebar_option from './components/Sidebar_option';
import './'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faGear } from '@fortawesome/free-solid-svg-icons/faGear';

function App() {
  var options ={
    'WMS':['Stock Movement','Pick ticket','Receipt'],
    'PM':['Option 1', 'Option 2', 'Option 3'],
    'EDI':['Option 1', 'Option 2', 'Option 3']

  } 
  var  header_options = Object.keys(options)
  // console.log(header_options)
  return (
    <div className="App">
       <header className="flex items-center justify-between bg-gray-300 p-4 m-2 rounded-lg">
        <div className="flex items-center space-x-4">
          <div className="bg-blue-300 w-16 h-16 flex items-center justify-center m-1">
            <span>Logo</span>
          </div>
          <div className="text-4xl font-bold">Company Name</div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="bg-blue-300 p-2 text-center">
            <div className='m-1'>Login user name</div>
            <div className='m-1'>Date</div>
          </div>
          <div>
          <FontAwesomeIcon icon={faGear} />
          <i class="fa-solid fa-gear"></i>
            <p>Settings</p>
          </div>
        </div>
      </header>
      <header>
      <div className="bg-gray-300 p-4 flex space-x-4 rounded-lg m-2 h-14">

       { header_options.map((x) =><button className="text-black rounded-full px-4 text-white hover:underline hover:underline-offset-2 font-bold hover:text-md ease-in  shadow-gray-500 hover:bg-gray-200 ">{x}</button>)}

          </div>
      </header>

      <main className="flex flex-1 h-[100vh] ">
        <aside className="bg-gray-200 border-r-gray-800  p-4 w-1/4 rounded-lg m-2">
        <SideBar options = {options}/>
        </aside>
        
        <section className="flex-1 p-4">
          Hero Section
        </section>
      </main>
    </div>
  );
}

export default App;
